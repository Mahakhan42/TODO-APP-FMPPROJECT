// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyC9nPZukH8SOaYwI3fcqLvvJRT4na8LWb0",
    authDomain: "project-todo-app-ba84a.firebaseapp.com",
    databaseURL: "https://project-todo-app-ba84a-default-rtdb.firebaseio.com",
    projectId: "project-todo-app-ba84a",
    storageBucket: "project-todo-app-ba84a.appspot.com",
    messagingSenderId: "1046613374996",
    appId: "1:1046613374996:web:26ccb5774e4d0bf567cf01"
  };
  
  // Initialize Firebase
var app = firebase.initializeApp(firebaseConfig);
// console.log(app.database);

var showlist = document.getElementById("showList");
firebase.database().ref("TODO LIST TIEM").on("child_added",function(data){
   console.log(data.val())
   if (inputField === "") {
    alert("Please Enter A Todo Item...");
    return;
}

// Create list element
var listElement = document.createElement("li");
var listText = document.createTextNode(data.val().value);
listElement.appendChild(listText);
// Show list
showlist.appendChild(listElement);


// Deleted button on list 
var deleteBtn = document.createElement("button");
var deleteText = document.createTextNode("Delete");
deleteBtn.appendChild(deleteText);
listElement.appendChild(deleteBtn);
deleteBtn.setAttribute("class", "btn");
deleteBtn.setAttribute("onclick", "deletedItems(this)");

// Edit button on list 
var editBtn = document.createElement("button");
var editText = document.createTextNode("Edit");
editBtn.appendChild(editText);
listElement.appendChild(editBtn);
editBtn.setAttribute("class", "Editbtn");
editBtn.setAttribute("onclick", "editItems(this)");
});

function addItems() {
    var inputField = document.getElementById("inputField");
    //  console.log(inputField.value)
    var database = firebase.database().ref("TODO LIST TIEM");
    var key = database.push().key;
    var TODO = {
        value:inputField.value,
        key:key,
    }
     database.child(key).set(TODO);


// Input text remove
document.getElementById("inputField").value = "";
}

// Deleted item function
function deletedItems(d) {
    d.parentNode.remove();
}

// Edit Function
function editItems(e) {
    var updateValue = prompt("Enter Updated Value...", e.parentNode.firstChild.nodeValue);
    if (updateValue !== null) {
        e.parentNode.firstChild.nodeValue = updateValue;
    }
}

// Deleted All
function deletedAllItems() {
    var deletedAll = document.getElementById("showList");
    deletedAll.innerHTML = "";
}
